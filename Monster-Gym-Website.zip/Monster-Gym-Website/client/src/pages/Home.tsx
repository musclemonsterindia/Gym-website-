import { useState, useEffect } from "react";
import { motion } from "framer-motion";
import { Link } from "react-scroll";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { insertContactSchema, type CreateContactRequest } from "@shared/schema";
import { useCreateContact } from "@/hooks/use-contacts";
import { WhatsAppButton } from "@/components/WhatsAppButton";
import { 
  Dumbbell, 
  Flame, 
  Users, 
  Activity, 
  Apple, 
  HeartPulse,
  Menu,
  X,
  Phone,
  Clock,
  User,
  ChevronRight,
  Send
} from "lucide-react";

import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import {
  Form,
  FormControl,
  FormField,
  FormItem,
  FormLabel,
  FormMessage,
} from "@/components/ui/form";
import { Card, CardContent } from "@/components/ui/card";

const navLinks = [
  { name: "Home", to: "home" },
  { name: "Services", to: "services" },
  { name: "Plans", to: "plans" },
  { name: "Gallery", to: "gallery" },
  { name: "Contact", to: "contact" },
];

const services = [
  { title: "Weight Gain", icon: Dumbbell, desc: "Build pure muscle mass with our specialized hypertrophy programs." },
  { title: "Weight Loss", icon: Flame, desc: "Shred fat fast with high-intensity interval training." },
  { title: "Personal Training", icon: Users, desc: "1-on-1 coaching customized to your exact body goals." },
  { title: "Bodybuilding", icon: Activity, desc: "Take your physique to the next level with pro bodybuilding prep." },
  { title: "Diet Counseling", icon: Apple, desc: "Nutrition plans designed to fuel your workouts and recovery." },
  { title: "Strength Training", icon: HeartPulse, desc: "Increase your raw power and functional strength." },
];

const plans = [
  { name: "Monthly Plan", price: "₹999", duration: "Per Month", features: ["Full Gym Access", "Free WiFi", "Locker Access", "1 PT Session"], popular: false },
  { name: "3 Month Plan", price: "₹2499", duration: "Quarterly", features: ["Full Gym Access", "Diet Plan", "Locker Access", "3 PT Sessions"], popular: true },
  { name: "Yearly Plan", price: "₹7999", duration: "Per Year", features: ["Full Gym Access", "Advanced Diet Plan", "Priority Support", "Monthly Body Analysis"], popular: false },
];

const galleryImages = [
  "https://images.unsplash.com/photo-1534438327276-14e5300c3a48?q=80&w=800",
  "https://images.unsplash.com/photo-1571019614242-c5c5dee9f50b?q=80&w=800",
  "https://images.unsplash.com/photo-1541534741688-6078c6bfb5c5?q=80&w=800",
  "https://images.unsplash.com/photo-1581009146145-b5ef050c2e1e?q=80&w=800",
  "https://images.unsplash.com/photo-1517836357463-d25dfeac3438?q=80&w=800",
  "https://images.unsplash.com/photo-1507398941214-572c25f4b1dc?q=80&w=800",
];

export default function Home() {
  const [isScrolled, setIsScrolled] = useState(false);
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);
  
  const createContact = useCreateContact();
  const form = useForm<CreateContactRequest>({
    resolver: zodResolver(insertContactSchema),
    defaultValues: { name: "", email: "", phone: "", message: "" },
  });

  useEffect(() => {
    const handleScroll = () => setIsScrolled(window.scrollY > 50);
    window.addEventListener("scroll", handleScroll);
    return () => window.removeEventListener("scroll", handleScroll);
  }, []);

  const onSubmit = (data: CreateContactRequest) => {
    createContact.mutate(data, {
      onSuccess: () => form.reset(),
    });
  };

  return (
    <div className="min-h-screen bg-background relative overflow-hidden">
      <WhatsAppButton />

      {/* NAVBAR */}
      <header 
        className={`fixed top-0 w-full z-50 transition-all duration-300 ${
          isScrolled ? "bg-black/90 backdrop-blur-md py-3 shadow-lg shadow-black/50 border-b border-white/5" : "bg-transparent py-5"
        }`}
      >
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 flex justify-between items-center">
          <div className="flex items-center gap-2">
            <Dumbbell className="w-8 h-8 text-primary" />
            <span className="font-display text-2xl md:text-3xl font-bold tracking-wider text-white">
              Muscle <span className="text-primary">Monster</span> Gym
            </span>
          </div>

          {/* Desktop Nav */}
          <nav className="hidden md:flex items-center gap-8">
            {navLinks.map((link) => (
              <Link
                key={link.to}
                to={link.to}
                spy={true}
                smooth={true}
                offset={-70}
                duration={500}
                className="text-sm font-semibold uppercase tracking-wider text-gray-300 hover:text-primary cursor-pointer transition-colors"
              >
                {link.name}
              </Link>
            ))}
            <Link to="contact" spy={true} smooth={true} offset={-70} duration={500}>
              <Button className="font-display uppercase tracking-widest text-lg px-8 rounded-none bg-primary hover:bg-primary/80">
                Join Now
              </Button>
            </Link>
          </nav>

          {/* Mobile Menu Toggle */}
          <button 
            className="md:hidden text-white hover:text-primary transition-colors"
            onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
          >
            {mobileMenuOpen ? <X className="w-8 h-8" /> : <Menu className="w-8 h-8" />}
          </button>
        </div>

        {/* Mobile Nav */}
        {mobileMenuOpen && (
          <motion.div 
            initial={{ opacity: 0, y: -20 }}
            animate={{ opacity: 1, y: 0 }}
            className="md:hidden absolute top-full left-0 w-full bg-black/95 backdrop-blur-xl border-b border-white/10 flex flex-col items-center py-6 gap-6"
          >
            {navLinks.map((link) => (
              <Link
                key={link.to}
                to={link.to}
                spy={true}
                smooth={true}
                offset={-70}
                duration={500}
                onClick={() => setMobileMenuOpen(false)}
                className="text-lg font-display uppercase tracking-wider text-gray-300 hover:text-primary cursor-pointer transition-colors"
              >
                {link.name}
              </Link>
            ))}
          </motion.div>
        )}
      </header>

      {/* HERO SECTION */}
      <section id="home" className="relative h-screen flex items-center justify-center pt-20">
        {/* landing page hero muscular person lifting weights */}
        <div 
          className="absolute inset-0 bg-cover bg-center bg-no-repeat z-0"
          style={{ backgroundImage: `url('https://images.unsplash.com/photo-1534438327276-14e5300c3a48?q=80&w=1920&fit=crop')` }}
        >
          <div className="absolute inset-0 bg-gradient-to-r from-black via-black/80 to-transparent"></div>
          <div className="absolute inset-0 bg-gradient-to-t from-background via-transparent to-transparent"></div>
        </div>

        <div className="relative z-10 max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 w-full">
          <motion.div 
            initial={{ opacity: 0, x: -50 }}
            animate={{ opacity: 1, x: 0 }}
            transition={{ duration: 0.8 }}
            className="max-w-3xl"
          >
            <div className="flex items-center gap-4 mb-4">
              <div className="h-[2px] w-12 bg-primary"></div>
              <span className="text-primary font-bold tracking-widest uppercase text-sm">No Excuses. Only Results.</span>
            </div>
            <h1 className="font-display text-6xl md:text-8xl lg:text-9xl font-bold leading-[0.9] text-white mb-6">
              Transform <br />
              <span className="text-transparent border-text relative z-10" style={{ WebkitTextStroke: "2px #E63946" }}>Your Body</span>
            </h1>
            <p className="text-gray-300 text-lg md:text-xl max-w-xl mb-10 border-l-4 border-primary pl-4">
              Join Muscle Monster Gym today and unleash your true potential. Experience state-of-the-art equipment and expert guidance.
            </p>
            <Link to="plans" spy={true} smooth={true} offset={-70} duration={500}>
              <Button size="lg" className="font-display text-xl uppercase tracking-widest px-10 py-8 rounded-none bg-primary hover:bg-white hover:text-black transition-all duration-300 group">
                Start Your Journey
                <ChevronRight className="ml-2 w-6 h-6 group-hover:translate-x-2 transition-transform" />
              </Button>
            </Link>
          </motion.div>
        </div>
      </section>

      {/* SERVICES SECTION */}
      <section id="services" className="py-24 relative bg-background">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <motion.div 
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            className="text-center mb-16"
          >
            <h2 className="font-display text-4xl md:text-5xl font-bold mb-4">Our <span className="text-primary">Services</span></h2>
            <p className="text-gray-400 max-w-2xl mx-auto">Everything you need to reach your fitness goals under one roof.</p>
          </motion.div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {services.map((service, idx) => (
              <motion.div
                key={service.title}
                initial={{ opacity: 0, y: 30 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                transition={{ delay: idx * 0.1 }}
              >
                <Card className="bg-card border-white/5 hover:border-primary/50 transition-colors duration-300 rounded-none group overflow-hidden">
                  <CardContent className="p-8">
                    <service.icon className="w-12 h-12 text-primary mb-6 group-hover:scale-110 transition-transform duration-300" />
                    <h3 className="font-display text-2xl font-bold mb-3">{service.title}</h3>
                    <p className="text-gray-400">{service.desc}</p>
                  </CardContent>
                  <div className="h-1 w-0 bg-primary group-hover:w-full transition-all duration-500 ease-out"></div>
                </Card>
              </motion.div>
            ))}
          </div>
        </div>
      </section>

      {/* PLANS SECTION */}
      <section id="plans" className="py-24 relative bg-[#0a0a0a]">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <motion.div 
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            className="text-center mb-16"
          >
            <h2 className="font-display text-4xl md:text-5xl font-bold mb-4">Membership <span className="text-primary">Plans</span></h2>
            <p className="text-gray-400 max-w-2xl mx-auto">Choose a plan that fits your goals and budget.</p>
          </motion.div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-8 max-w-5xl mx-auto">
            {plans.map((plan, idx) => (
              <motion.div
                key={plan.name}
                initial={{ opacity: 0, y: 30 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                transition={{ delay: idx * 0.2 }}
                className={`relative ${plan.popular ? '-mt-4 mb-4 md:mb-0 md:-mt-8' : ''}`}
              >
                {plan.popular && (
                  <div className="absolute -top-4 inset-x-0 flex justify-center z-10">
                    <span className="bg-primary text-white text-xs font-bold px-4 py-1 rounded-full uppercase tracking-wider">Most Popular</span>
                  </div>
                )}
                <Card className={`h-full bg-card rounded-none transition-all duration-300 ${
                  plan.popular 
                    ? 'border-primary shadow-[0_0_30px_-5px_rgba(225,29,72,0.2)]' 
                    : 'border-white/5 hover:border-white/20'
                }`}>
                  <CardContent className="p-8 flex flex-col h-full">
                    <div className="text-center mb-8 pb-8 border-b border-white/10">
                      <h3 className="font-display text-2xl font-medium text-gray-300 mb-2">{plan.name}</h3>
                      <div className="flex justify-center items-end gap-1">
                        <span className="text-5xl font-bold font-display text-white">{plan.price}</span>
                      </div>
                      <span className="text-sm text-primary font-medium mt-2 block">{plan.duration}</span>
                    </div>
                    
                    <ul className="space-y-4 flex-grow mb-8">
                      {plan.features.map((feature, i) => (
                        <li key={i} className="flex items-center gap-3 text-gray-300">
                          <div className="w-1.5 h-1.5 rounded-full bg-primary" />
                          {feature}
                        </li>
                      ))}
                    </ul>

                    <Link to="contact" spy={true} smooth={true} offset={-70} duration={500} className="w-full">
                      <Button 
                        variant={plan.popular ? "default" : "outline"}
                        className={`w-full rounded-none font-display uppercase tracking-widest text-lg h-12 ${
                          plan.popular ? 'bg-primary hover:bg-white hover:text-black' : 'border-white/20 text-white hover:bg-white/10'
                        }`}
                      >
                        Choose Plan
                      </Button>
                    </Link>
                  </CardContent>
                </Card>
              </motion.div>
            ))}
          </div>
        </div>
      </section>

      {/* GALLERY SECTION */}
      <section id="gallery" className="py-24 relative bg-background">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <motion.div 
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            className="text-center mb-16"
          >
            <h2 className="font-display text-4xl md:text-5xl font-bold mb-4">Gym <span className="text-primary">Gallery</span></h2>
            <p className="text-gray-400 max-w-2xl mx-auto">Take a look inside the monster's den.</p>
          </motion.div>

          <div className="grid grid-cols-2 md:grid-cols-3 gap-2 md:gap-4">
            {galleryImages.map((img, idx) => (
              <motion.div
                key={idx}
                initial={{ opacity: 0, scale: 0.9 }}
                whileInView={{ opacity: 1, scale: 1 }}
                viewport={{ once: true }}
                transition={{ delay: idx * 0.1 }}
                className="relative aspect-square overflow-hidden group cursor-pointer"
              >
                <div className="absolute inset-0 bg-primary/20 opacity-0 group-hover:opacity-100 transition-opacity duration-300 z-10" />
                <img 
                  src={img} 
                  alt={`Gym Activity ${idx + 1}`} 
                  className="w-full h-full object-cover transition-transform duration-700 group-hover:scale-110"
                />
              </motion.div>
            ))}
          </div>
        </div>
      </section>

      {/* CONTACT SECTION */}
      <section id="contact" className="py-24 relative bg-[#050505]">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-16">
            
            {/* Contact Info */}
            <motion.div 
              initial={{ opacity: 0, x: -30 }}
              whileInView={{ opacity: 1, x: 0 }}
              viewport={{ once: true }}
            >
              <h2 className="font-display text-4xl md:text-5xl font-bold mb-6">Get In <span className="text-primary">Touch</span></h2>
              <p className="text-gray-400 mb-10 text-lg">
                Ready to transform? Drop us a message or visit the gym directly. Golu is always ready to push you to your limits!
              </p>

              <div className="space-y-8">
                <div className="flex items-start gap-4">
                  <div className="w-12 h-12 bg-primary/10 rounded-full flex items-center justify-center flex-shrink-0">
                    <User className="w-6 h-6 text-primary" />
                  </div>
                  <div>
                    <h4 className="font-display text-xl mb-1 text-white">Owner</h4>
                    <p className="text-gray-400">Srijal (Golu)</p>
                  </div>
                </div>

                <div className="flex items-start gap-4">
                  <div className="w-12 h-12 bg-primary/10 rounded-full flex items-center justify-center flex-shrink-0">
                    <Phone className="w-6 h-6 text-primary" />
                  </div>
                  <div>
                    <h4 className="font-display text-xl mb-1 text-white">Phone</h4>
                    <p className="text-gray-400">9625356627</p>
                  </div>
                </div>

                <div className="flex items-start gap-4">
                  <div className="w-12 h-12 bg-primary/10 rounded-full flex items-center justify-center flex-shrink-0">
                    <Clock className="w-6 h-6 text-primary" />
                  </div>
                  <div>
                    <h4 className="font-display text-xl mb-1 text-white">Open Time</h4>
                    <p className="text-gray-400">6:00 AM – 10:00 PM</p>
                    <p className="text-gray-500 text-sm mt-1">Monday to Saturday (Sunday Closed)</p>
                  </div>
                </div>
              </div>
            </motion.div>

            {/* Contact Form */}
            <motion.div 
              initial={{ opacity: 0, x: 30 }}
              whileInView={{ opacity: 1, x: 0 }}
              viewport={{ once: true }}
              className="bg-card p-8 md:p-10 border border-white/5"
            >
              <h3 className="font-display text-3xl font-bold mb-6 text-white">Send a Message</h3>
              <Form {...form}>
                <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-6">
                  <FormField
                    control={form.control}
                    name="name"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel className="text-gray-300">Full Name</FormLabel>
                        <FormControl>
                          <Input placeholder="John Doe" {...field} className="bg-background border-white/10 rounded-none h-12 focus-visible:ring-primary focus-visible:border-primary text-white" />
                        </FormControl>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                  
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                    <FormField
                      control={form.control}
                      name="email"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel className="text-gray-300">Email Address</FormLabel>
                          <FormControl>
                            <Input placeholder="john@example.com" type="email" {...field} className="bg-background border-white/10 rounded-none h-12 focus-visible:ring-primary focus-visible:border-primary text-white" />
                          </FormControl>
                          <FormMessage />
                        </FormItem>
                      )}
                    />
                    <FormField
                      control={form.control}
                      name="phone"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel className="text-gray-300">Phone Number</FormLabel>
                          <FormControl>
                            <Input placeholder="9876543210" {...field} className="bg-background border-white/10 rounded-none h-12 focus-visible:ring-primary focus-visible:border-primary text-white" />
                          </FormControl>
                          <FormMessage />
                        </FormItem>
                      )}
                    />
                  </div>

                  <FormField
                    control={form.control}
                    name="message"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel className="text-gray-300">Your Message</FormLabel>
                        <FormControl>
                          <Textarea 
                            placeholder="I want to join the 3 month plan..." 
                            className="bg-background border-white/10 rounded-none min-h-[120px] resize-none focus-visible:ring-primary focus-visible:border-primary text-white"
                            {...field} 
                          />
                        </FormControl>
                        <FormMessage />
                      </FormItem>
                    )}
                  />

                  <Button 
                    type="submit" 
                    disabled={createContact.isPending}
                    className="w-full h-14 rounded-none bg-primary hover:bg-white hover:text-black font-display text-lg tracking-widest uppercase transition-all duration-300 group"
                  >
                    {createContact.isPending ? "Sending..." : "Send Message"}
                    {!createContact.isPending && <Send className="ml-2 w-5 h-5 group-hover:translate-x-1 transition-transform" />}
                  </Button>
                </form>
              </Form>
            </motion.div>
          </div>
        </div>
      </section>

      {/* FOOTER */}
      <footer className="bg-black py-10 border-t border-white/10 text-center">
        <div className="max-w-7xl mx-auto px-4 flex flex-col items-center">
          <div className="flex items-center gap-2 mb-6">
            <Dumbbell className="w-6 h-6 text-primary" />
            <span className="font-display text-xl font-bold tracking-wider text-white">
              Muscle <span className="text-primary">Monster</span> Gym
            </span>
          </div>
          <p className="text-gray-500 text-sm">
            © {new Date().getFullYear()} Muscle Monster Gym. Built for the monsters. All rights reserved.
          </p>
        </div>
      </footer>
    </div>
  );
}
